package com.envestnet.usermanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.envestnet.usermanagement.domain.UserRegistrationEntity;

public class UserRegistrationDAO {

	public int saveUserRegistration(UserRegistrationEntity userReg,Connection conn) throws SQLException{
		
		int status=-1;
		String sql="insert into t_user_registration(name,user_id,password,agreement,"+
		"gender,dob) values(?,?,?,?,?,?)";
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			
			pst.setString(1, userReg.getName());
			pst.setString(2, userReg.getUserId());
			pst.setString(3, userReg.getPassword());
			pst.setString(4, userReg.getAgreement());
			pst.setString(5, userReg.getGender());
			pst.setDate(6, userReg.getDob());
			
			status=pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
			throw e;
		}
		
		return status;
		
	}
}
