package com.envestnet.usermanagement.controller;

public interface UserAction {

	String USER_ACTION="userAction";
	
	String SUBMIT_REGISTRATION="submitRegistration";
	String REGISTRATION="registration";
	String SUBMIT_LOGIN = "submitLogin";
	String LOGIN = "login";
	String ABOUT = "about";
	
	
}
