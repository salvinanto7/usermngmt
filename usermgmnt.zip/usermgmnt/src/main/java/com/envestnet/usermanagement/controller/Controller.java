package com.envestnet.usermanagement.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.envestnet.usermanagement.domain.UserRegistrationEntity;
import com.envestnet.usermanagement.dto.DBConfDTO;
import com.envestnet.usermanagement.handler.Handler;
import com.envestnet.usermanagement.handler.RegistrationHandler;
import com.envestnet.usermanagement.service.UserRegistrationService;

public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html");
		
		String userAction = request.getParameter(UserAction.USER_ACTION);
		
		
		if(UserAction.SUBMIT_REGISTRATION.equals(userAction)) {
			Handler handle = new RegistrationHandler();
			String viewId=handle.handleRequest(request, response);
			request.getRequestDispatcher(viewId).forward(request, response);
		}
		else if(UserAction.REGISTRATION.equals(userAction)) {
			response.sendRedirect("reg.jsp");
		}
		else if(UserAction.LOGIN.equals(userAction)) {
			response.sendRedirect("login.jsp");
		}
		else if(UserAction.ABOUT.equals(userAction)) {
			response.sendRedirect("about.html");
		}	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	@Override
	public void init(ServletConfig config) throws ServletException {

		DBConfDTO dbConf = new DBConfDTO();

		dbConf.setDriver(config.getInitParameter("driver"));
		dbConf.setUrl(config.getInitParameter("url"));
		dbConf.setUser(config.getInitParameter("user"));
		dbConf.setPassword(config.getInitParameter("password"));

		config.getServletContext().setAttribute("dbConf", dbConf);

	}

}
