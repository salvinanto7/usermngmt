package com.envestnet.usermanagement.handler;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.envestnet.usermanagement.domain.UserRegistrationEntity;
import com.envestnet.usermanagement.dto.DBConfDTO;
import com.envestnet.usermanagement.service.UserRegistrationService;

public class RegistrationHandler implements Handler {
	
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		UserRegistrationEntity regEntity= createRegisration(request);
		DBConfDTO dbConf = (DBConfDTO) request.getServletContext().getAttribute("dbConf");
		UserRegistrationService rs = new UserRegistrationService(dbConf);
		String message = rs.saveUserRegistration(regEntity);
		
		if("success".equals(message)) {
			return "login.jsp";
		}
		
		return "reg.jsp";
	}

	private UserRegistrationEntity createRegisration(HttpServletRequest request) {

		UserRegistrationEntity reg = new UserRegistrationEntity();

		reg.setName(request.getParameter("name"));
		reg.setUserId(request.getParameter("userId"));
		reg.setPassword(request.getParameter("password"));
		reg.setGender(request.getParameter("gender"));
		
		java.sql.Date dob = getDoB(request);
		reg.setDob(dob);
		reg.setAgreement(request.getParameter("agreement")==null?"N":"Y");

		return reg;

	}

	private java.sql.Date getDoB(HttpServletRequest request) {
		
		java.util.Date tmpDob=null;
		try {
			tmpDob = dateFormat.parse(request.getParameter("dob"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		java.sql.Date dob = new java.sql.Date(tmpDob.getTime());
		return dob;
	}

}
