package com.envestnet.usermanagement.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.envestnet.usermanagement.dao.DBConnection;
import com.envestnet.usermanagement.dao.H2DBConnection;
import com.envestnet.usermanagement.dao.UserRegistrationDAO;
import com.envestnet.usermanagement.domain.UserRegistrationEntity;
import com.envestnet.usermanagement.dto.DBConfDTO;

public class UserRegistrationService {

	private DBConfDTO dbConf;
	
	public UserRegistrationService(DBConfDTO dbConf) {
		this.dbConf=dbConf;
	}
	public String saveUserRegistration(UserRegistrationEntity userReg) {

		DBConnection conn = new H2DBConnection();
		Connection h2Conn = null;
		int status=-1;
		String message=null;
		try {
			h2Conn = conn.createConnection(dbConf);
			System.out.println("Connected...");
			UserRegistrationDAO dao = new UserRegistrationDAO();
			status=dao.saveUserRegistration(userReg, h2Conn);
			h2Conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			try {
				if (h2Conn != null && !h2Conn.isClosed()) {
					h2Conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			message=status>0?"success":"Registration failed";
		}
		
		return message;
	}
}
