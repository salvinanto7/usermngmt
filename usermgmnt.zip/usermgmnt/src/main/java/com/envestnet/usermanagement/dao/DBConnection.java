package com.envestnet.usermanagement.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContext;

import com.envestnet.usermanagement.dto.DBConfDTO;

public interface DBConnection {

	Connection createConnection(DBConfDTO dbConf) throws SQLException;
}
