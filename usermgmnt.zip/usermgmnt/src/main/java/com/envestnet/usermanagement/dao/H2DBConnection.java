package com.envestnet.usermanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;

import com.envestnet.usermanagement.dto.DBConfDTO;


public class H2DBConnection implements DBConnection {
	
	private static Class driverClass;
	
	public Connection createConnection(DBConfDTO conf) throws SQLException {
		
		if(driverClass==null) {
			loadDriver(conf.getDriver());
		}
		return DriverManager.getConnection(conf.getUrl(),conf.getUser(),conf.getPassword());
		
	}
	
	
	private static void loadDriver(String driver) {
		try {
			driverClass=Class.forName(driver);
			System.out.println("driver loaded.");
		} catch (ClassNotFoundException e) {
			System.err.println("Not able to load driver.");
			e.printStackTrace();
		}
	}
}
